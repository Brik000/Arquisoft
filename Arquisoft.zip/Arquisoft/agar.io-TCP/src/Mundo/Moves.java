package Mundo;

public interface Moves {
	
	void move();
	void changeDirection(double x,double y);

}
